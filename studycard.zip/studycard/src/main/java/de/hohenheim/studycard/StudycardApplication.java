package de.hohenheim.studycard;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class StudycardApplication {

    public static void main(String[] args) {
        SpringApplication.run(StudycardApplication.class, args);
    }
}
